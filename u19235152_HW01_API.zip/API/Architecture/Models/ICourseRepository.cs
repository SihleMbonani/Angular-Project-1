﻿using Architecture.ViewModel;

namespace Architecture.Models
{
    public interface ICourseRepository
    {
        // Course
        Task<Course[]> GetAllCourseAsync();
        Task<CourseViewModel> GetCourseAsync(int cId);
        Task<int> AddCourseAsync(CourseViewModel course);
        Task<int> EditCourseAsync(int cId, CourseViewModel course);
        Task<int> DeleteCourseAsync(int cId);

    }
}
