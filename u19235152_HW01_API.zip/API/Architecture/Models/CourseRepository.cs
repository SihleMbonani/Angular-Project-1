﻿using Architecture.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace Architecture.Models
{
    public class CourseRepository : ICourseRepository
    {
        private readonly AppDbContext _appDbContext;

        public CourseRepository(AppDbContext appDbContext)
        {
                _appDbContext = appDbContext;
        }
        
        //the task is to return a list of courses, call the method GetAllCourses
        public async Task<Course[]> GetAllCourseAsync()
        {
            IQueryable<Course> query = _appDbContext.Courses;
            return await query.ToArrayAsync(); // return all the courses
        }

        //Another READ
        //Method can onlt return a method type
        public async Task<CourseViewModel> GetCourseAsync(int cId)
        {
            CourseViewModel courseObj = new CourseViewModel();
            Course query = await _appDbContext.Courses.Where(x=> x.CourseId == cId).FirstOrDefaultAsync();
            if(query == null)
            {
                //err code
                courseObj.responses = 404;
            }
            else
            {
                courseObj.CourseId = query.CourseId;
                courseObj.Name = query.Name;
                courseObj.Duration = query.Duration;
                courseObj.Description = query.Description;
                courseObj.responses = 200;
            }
            return courseObj;

        }

        public async Task<int> AddCourseAsync(CourseViewModel course) 
        {
            int code = 200;
            try
            {
                Course Acourse = new Course();
                Acourse.Name = course.Name;
                Acourse.Duration = course.Duration;
                Acourse.Description = course.Description;
                await _appDbContext.Courses.AddAsync(Acourse);
               // _appDbContext.Courses.AddAsync(course)
               await _appDbContext.SaveChangesAsync();
             }
            catch (Exception ex)
            {
                code = 500;
            }
            return code;
        }

        //Updating
        //so need unique identifier to reference- ID
        //then change value we need to update
        //UPDATE[Architecture].[dbo].[Courses] SET [Name] = 'INL 330',
        //Description]='',[Duration]='Semester 1' WHERE CourseId='3'
        public async Task<int> EditCourseAsync(int cId, CourseViewModel course)
        {
            int rCode = 200;
            //1.Locate the object in the db based on course id we send through

            Course FindIdDb = await _appDbContext.Courses.Where(x => x.CourseId == cId).FirstOrDefaultAsync();
            if(FindIdDb == null)
            {
                rCode = 400;
            }
            else
            {
                FindIdDb.Name = course.Name;
                FindIdDb.Description = course.Description;
                FindIdDb.Duration = course.Duration;
                _appDbContext.Courses.Update(FindIdDb);
                await _appDbContext.SaveChangesAsync();
        
            }
            return rCode;
        }

        //Deleting
        public async Task<int> DeleteCourseAsync(int cId)
        {
            int rCode = 200;
            //1.Locate the object in the db based on course id we send through
            //find the id we want t delete

            Course FindIdDb = await _appDbContext.Courses.Where(x => x.CourseId == cId).FirstOrDefaultAsync();
            if (FindIdDb == null)
            {
                rCode = 400;
            }
            else
            {
                _appDbContext.Courses.Remove(FindIdDb);
                await _appDbContext.SaveChangesAsync();

            }
            return rCode;
        }
    }
}
