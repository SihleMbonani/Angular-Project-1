﻿using Architecture.Models;
using Architecture.ViewModel;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace Architecture.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ICourseRepository _courseRepository;

        public CourseController(ICourseRepository courseRepository)
        {
            _courseRepository = courseRepository;
        }

        //Gets all the courses on the page
        [HttpGet]
        [Route("GetAllCourses")]
        public async Task<IActionResult> GetAllCourses()
        {
            try
            {
                var results = await _courseRepository.GetAllCourseAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500,"Internal Server Error. Please contact support.");
            }
        }

        //Getiing the individual instance
        [HttpGet]
        [Route("GetCourses/{courseId}")]
        public async Task<IActionResult> GetCourses(int courseId)
        {
            try
            {
                var results = await _courseRepository.GetCourseAsync(courseId);
                if(results == null)
                {
                    return StatusCode(404, "Ooops, unable to retrieve course");
                   // return BadRequest("Sorry, Unable to get the provided course");
                }
                else if(results.responses==200)
                {
                    return Ok(results);
                }
                else
                {
                    return Ok("Please try again");
                }
               
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        //use courseview model to receive course
        [HttpPost]
        [Route("AddCourses")]
        public async Task<IActionResult> AddCourses(CourseViewModel course)
        {
            try
            {
                var results = await _courseRepository.AddCourseAsync(course);
                if(results == 200)
                {
                    return Ok("Suceess: Added "+ course.Name);
                }
                else
                {
                    return BadRequest("Error: Unable to add your course");
                }
                
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpPut]
        [Route("EditCourses/{cId}")]
        public async Task<IActionResult> EditCourses(int cId, CourseViewModel course)
        {
            try
            {
                var results = await _courseRepository.EditCourseAsync(cId, course);
                if (results == 200)
                {
                    return Ok("Suceess: Updated " + course.Name);
                }
                else
                {
                    return BadRequest("Error: Unable to update your course");
                }

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpDelete]
        [Route("DeleteCourses/{cId}")]
        public async Task<IActionResult> DeleteCourses(int cId)
        {
            try
            {
                var results = await _courseRepository.DeleteCourseAsync(cId);
                if (results == 200) //if everything is fine then return sucess code
                {
                    //return Ok(results);
                    //other way
                    var deleteResponse = new OkObjectResult(new {message ="Deleted course no: "+ cId, StatusCode=200});
                    return deleteResponse;
                    //return StatusCode(200, "Suceess: Dleleted course " + cId);
                    //return Ok("Suceess: Dleleted course " + cId);
                }
                else
                {
                    //var deleteResponse = new OkObjectResult(new {message ="Deleted course no: "+ cId, StatusCode=404});
                    //return deleteResponse;
                    return BadRequest("Error: Unable to delete your course");
                }

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

    }
}

//terminal 
//if tested delete button
//delete db in SQL first
//add-migration
//update database
//build
