﻿namespace Architecture.ViewModel
{
    public class CourseViewModel
    {
        public string Name { get; set; }
        public string Duration { get; set; }
        public string Description { get; set; }
        public int LocationId { get; set; }
        public int responses { get; set; }
        public int CourseId { get; set; }
    }
}
